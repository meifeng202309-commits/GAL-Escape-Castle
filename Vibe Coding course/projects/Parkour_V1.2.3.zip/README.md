# Parkour V1.2.3

Skill 2 — Asset Generation & Integration

This build is based directly on Parkour v1.2.

## Change from v1.2
- Replaced only the original procedural background with a high-resolution AI-generated city-night background.
- The background is stored as an external asset: `assets/city-night-hd.png`.
- The background scrolls horizontally and repeats during play.
- v1.2 player, hurdles, speed, obstacle frequency, collision logic, and controls are retained.

## Local run
Keep the folder structure unchanged and open `index.html` in a browser.

## Controls
- Space / Arrow Up: jump
- Arrow Down: slide
- R / Space after Game Over: restart
